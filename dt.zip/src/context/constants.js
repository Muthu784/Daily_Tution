export const currency = '$';
export const currentYear = new Date().getFullYear();
export const developedByLink = '';
export const developedBy = '';
export const contactUs = 'contact.dailytuition@gmail.com';
export const buyLink = '';
export const basePath = '/Dailytuition/';
export const DEFAULT_PAGE_TITLE = '';

// Replace the URL's value in env with your backend's URL or if you're using nextjs's API, add the server's origin URL
export const API_BASE_PATH = '';
export const colorVariants = ['primary', 'secondary', 'success', 'danger', 'warning', 'info', 'dark', 'purple', 'pink', 'orange', 'light', 'link'];