import FullView from './components/FullView';
const FullViewPage = () => {
  return <FullView />;
};
export default FullViewPage;