import FullScreenView from './components/FullScreenView';
const FullScreenViewPage = () => {
  return <FullScreenView />;
};
export default FullScreenViewPage;