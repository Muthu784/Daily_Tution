import HoverMenu from './components/HoverMenu';
const HoverMenuPage = () => {
  return <HoverMenu />;
};
export default HoverMenuPage;