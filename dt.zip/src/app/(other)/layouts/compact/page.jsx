import Compact from './components/Compact';
const CompactPage = () => {
  return <Compact />;
};
export default CompactPage;