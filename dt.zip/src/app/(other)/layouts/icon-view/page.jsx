import IconView from './components/IconView';
const IconViewPage = () => {
  return <IconView />;
};
export default IconViewPage;