import PageBreadcrumb from '@/components/PageBreadcrumb';
import AllSelect from './components/AllSelect';

// 

const SelectForm = () => {
  return <>
      <PageBreadcrumb title='Select Form' />
      <AllSelect />
    </>;
};
export default SelectForm;