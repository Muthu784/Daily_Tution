import PageBreadcrumb from '@/components/PageBreadcrumb';

// 

const StarterPage = () => {
  return <>
    <PageBreadcrumb title='Starter Page' />
    </>;
};
export default StarterPage;